#!/bin/bash
date
date +%s
curr_time=$(date +%s)
let curr_time=curr_time*2
echo "The current_time*2 is : $curr_time "

for i in {1..20}; do 
	echo "Number: $i"
done
